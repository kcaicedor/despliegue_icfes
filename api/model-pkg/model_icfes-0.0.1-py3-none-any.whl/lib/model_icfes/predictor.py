
from pathlib import Path
from functools import lru_cache

import joblib
import pandas as pd


FECHA_EXAMEN = pd.Timestamp("2022-09-02")

COLUMNAS_BORRAR = [
    "periodo",
    "estu_tipodocumento",
    "estu_consecutivo",
    "cole_codigo_icfes",
    "cole_cod_dane_establecimiento",
    "cole_cod_dane_sede",
    "cole_cod_depto_ubicacion",
    "cole_cod_mcpio_ubicacion",
    "cole_depto_ubicacion",
    "cole_mcpio_ubicacion",
    "estu_cod_depto_presentacion",
    "estu_cod_mcpio_presentacion",
    "estu_cod_reside_depto",
    "estu_cod_reside_mcpio",
    "estu_estudiante",
    "punt_matematicas",
    "punt_sociales_ciudadanas",
    "punt_c_naturales",
    "punt_lectura_critica",
    "punt_ingles",
    "desemp_ingles"
]


RUTA_MODELO = (
    Path(__file__).parent
    / "artifacts"
    / "modelo_regresion_lineal.joblib"
)


@lru_cache(maxsize=1)
def cargar_modelo():

    if not RUTA_MODELO.exists():
        raise FileNotFoundError(
            f"No se encontró el modelo: {RUTA_MODELO}"
        )

    return joblib.load(RUTA_MODELO)


def preparar_datos(datos):

    df = pd.DataFrame(datos).copy()

    # Eliminar columnas que no utiliza el modelo
    df = df.drop(
        columns=COLUMNAS_BORRAR,
        errors="ignore"
    )

    # Si viene el puntaje real, no debe utilizarse
    # como variable de entrada.
    df = df.drop(
        columns=["punt_global"],
        errors="ignore"
    )

    # Calcular edad
    if "estu_fechanacimiento" in df.columns:

        df["estu_fechanacimiento"] = pd.to_datetime(
            df["estu_fechanacimiento"],
            format="%d/%m/%Y",
            errors="coerce"
        )

        df["edad"] = (
            FECHA_EXAMEN.year
            - df["estu_fechanacimiento"].dt.year
            - (
                (
                    df["estu_fechanacimiento"].dt.month
                    > FECHA_EXAMEN.month
                )
                |
                (
                    (
                        df["estu_fechanacimiento"].dt.month
                        == FECHA_EXAMEN.month
                    )
                    &
                    (
                        df["estu_fechanacimiento"].dt.day
                        > FECHA_EXAMEN.day
                    )
                )
            ).astype(int)
        )

        df = df.drop(
            columns=["estu_fechanacimiento"]
        )

    return df


def predecir(datos):

    modelo = cargar_modelo()

    df = preparar_datos(datos)

    predicciones = modelo.predict(df)

    return predicciones.tolist()
