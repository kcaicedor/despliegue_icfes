
from pathlib import Path
from functools import lru_cache

import joblib
import pandas as pd
import numpy as np


FECHA_EXAMEN = pd.Timestamp("2022-09-02")

COLUMNAS_BORRAR = [
    "periodo",
    "estu_tipodocumento",
    "estu_consecutivo",
    "cole_codigo_icfes",
    "cole_cod_dane_establecimiento",
    "cole_cod_dane_sede",
    "cole_cod_depto_ubicacion",
    "cole_cod_mcpio_ubicacion",
    "cole_depto_ubicacion",
    "cole_mcpio_ubicacion",
    "estu_cod_depto_presentacion",
    "estu_cod_mcpio_presentacion",
    "estu_cod_reside_depto",
    "estu_cod_reside_mcpio",
    "estu_estudiante",
    "punt_matematicas",
    "punt_sociales_ciudadanas",
    "punt_c_naturales",
    "punt_lectura_critica",
    "punt_ingles",
    "desemp_ingles"
]


RUTA_MODELO = (
    Path(__file__).parent
    / "artifacts"
    / "modelo_regresion_lineal.joblib"
)


@lru_cache(maxsize=1)
def cargar_modelo():

    if not RUTA_MODELO.exists():
        raise FileNotFoundError(
            f"No se encontró el modelo: {RUTA_MODELO}"
        )

    return joblib.load(RUTA_MODELO)


def preparar_datos(datos):

    df = pd.DataFrame(datos).copy()

    # Eliminar columnas que no utiliza el modelo
    df = df.drop(
        columns=COLUMNAS_BORRAR,
        errors="ignore"
    )

    # Si viene el puntaje real, no debe utilizarse
    # como variable de entrada.
    df = df.drop(
        columns=["punt_global"],
        errors="ignore"
    )

    # Calcular edad
    if "estu_fechanacimiento" in df.columns:

        df["estu_fechanacimiento"] = pd.to_datetime(
            df["estu_fechanacimiento"],
            format="%d/%m/%Y",
            errors="coerce"
        )

        df["edad"] = (
            FECHA_EXAMEN.year
            - df["estu_fechanacimiento"].dt.year
            - (
                (
                    df["estu_fechanacimiento"].dt.month
                    > FECHA_EXAMEN.month
                )
                |
                (
                    (
                        df["estu_fechanacimiento"].dt.month
                        == FECHA_EXAMEN.month
                    )
                    &
                    (
                        df["estu_fechanacimiento"].dt.day
                        > FECHA_EXAMEN.day
                    )
                )
            ).astype(int)
        )

        df = df.drop(
            columns=["estu_fechanacimiento"]
        )

    return df

def obtener_explicabilidad_lineal(
    pipeline,
    df_inputs: pd.DataFrame,
    top_n: int = 5
):
    # Obtener los componentes del pipeline
    preprocesador = pipeline.named_steps["preprocesamiento"]
    regresor = pipeline.named_steps["modelo"]

    # Transformar los datos
    X_trans = preprocesador.transform(df_inputs)

    if hasattr(X_trans, "toarray"):
        X_trans = X_trans.toarray()

    X_trans = np.asarray(X_trans)

    # Obtener nombres de variables transformadas
    nombres_trans = preprocesador.get_feature_names_out()

    coefs = np.asarray(regresor.coef_).reshape(-1)

    # Validar dimensiones
    if X_trans.shape[1] != len(coefs):
        raise ValueError(
            "Las dimensiones de los datos transformados "
            "no coinciden con los coeficientes del modelo."
        )

    # Mapear variables transformadas a variables originales
    variables_originales = df_inputs.columns.tolist()
    mapa_origen = []

    for nombre in nombres_trans:

        limpio = nombre.split("__", 1)[-1]

        coincidencias = [
            col for col in variables_originales
            if limpio == col or limpio.startswith(col + "_")
        ]

        origen = (
            max(coincidencias, key=len)
            if coincidencias
            else limpio
        )

        mapa_origen.append(origen)

    # ----------------------------------------
    # 1. IMPORTANCIA GLOBAL
    # ----------------------------------------

    df_global = pd.DataFrame({
        "variable": mapa_origen,
        "peso": np.abs(coefs)
    })

    top_global = (
        df_global.groupby("variable")["peso"].max()
        .sort_values(ascending=False)
        .head(top_n)
        .round(2)
        .reset_index()
        .to_dict(orient="records")
    )

    # ----------------------------------------
    # 2. CONTRIBUCIONES INDIVIDUALES
    # ----------------------------------------

    contribuciones_matriz = X_trans * coefs

    contribuciones_lista = []

    for fila in contribuciones_matriz:

        df_ind = pd.DataFrame({
            "variable": mapa_origen,
            "contribucion": fila
        })

        agrupado = (
            df_ind.groupby("variable")["contribucion"].sum()
        )

        top_ind = agrupado.reindex(
            agrupado.abs().sort_values(ascending=False).index
        ).head(top_n)

        contribuciones_lista.append([
            {
                "variable": var,
                "contribucion": round(float(val), 2)
            }
            for var, val in top_ind.items()
        ])

    return top_global, contribuciones_lista

def predecir(datos):

    modelo = cargar_modelo()

    df = preparar_datos(datos)

    predicciones = modelo.predict(df)

    return predicciones.tolist()
